package dao;

public class EntidadesDAO {
	
	
	

}
