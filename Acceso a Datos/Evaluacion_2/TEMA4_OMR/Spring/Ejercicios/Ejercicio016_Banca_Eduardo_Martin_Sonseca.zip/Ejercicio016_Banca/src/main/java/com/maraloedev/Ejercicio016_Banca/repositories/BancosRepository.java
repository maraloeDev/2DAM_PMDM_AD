package com.maraloedev.Ejercicio016_Banca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maraloedev.Ejercicio016_Banca.entites.Bancos;

public interface BancosRepository extends JpaRepository<Bancos, Long> {

}
