package com.maraloedev.Ejercicio016_Banca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio016BancaApplicationTests {

	@Test
	void contextLoads() {
	}

}
