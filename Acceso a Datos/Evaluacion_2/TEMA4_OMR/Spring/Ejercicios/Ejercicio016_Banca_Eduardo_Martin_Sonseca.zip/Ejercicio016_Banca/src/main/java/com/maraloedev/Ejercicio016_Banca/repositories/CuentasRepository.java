package com.maraloedev.Ejercicio016_Banca.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maraloedev.Ejercicio016_Banca.entites.Cuentas;

public interface CuentasRepository extends JpaRepository<Cuentas, Long> {

}
