package com.maraloedev.Ejercicio016_Banca;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio016BancaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio016BancaApplication.class, args);
	}
}
