package com.maraloedev.Ejercicio015_Proyecto_Web_Gestion_de_Matriculas_en_Spring_Boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio015ProyectoWebGestionDeMatriculasEnSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
