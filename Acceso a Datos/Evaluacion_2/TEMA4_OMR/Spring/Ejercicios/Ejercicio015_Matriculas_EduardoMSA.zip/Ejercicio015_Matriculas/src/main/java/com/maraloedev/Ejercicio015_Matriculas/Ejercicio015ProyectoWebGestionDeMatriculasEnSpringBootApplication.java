package com.maraloedev.Ejercicio015_Matriculas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio015ProyectoWebGestionDeMatriculasEnSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio015ProyectoWebGestionDeMatriculasEnSpringBootApplication.class, args);
	}

}
