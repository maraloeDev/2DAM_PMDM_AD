package com.maraloedev.Ejercicio018_Skills;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio018SkillsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio018SkillsApplication.class, args);
	}

}
