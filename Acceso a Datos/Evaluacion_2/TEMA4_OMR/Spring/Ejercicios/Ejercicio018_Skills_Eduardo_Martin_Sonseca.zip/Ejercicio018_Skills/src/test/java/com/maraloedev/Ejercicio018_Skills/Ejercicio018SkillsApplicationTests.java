package com.maraloedev.Ejercicio018_Skills;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio018SkillsApplicationTests {

	@Test
	void contextLoads() {
	}

}
