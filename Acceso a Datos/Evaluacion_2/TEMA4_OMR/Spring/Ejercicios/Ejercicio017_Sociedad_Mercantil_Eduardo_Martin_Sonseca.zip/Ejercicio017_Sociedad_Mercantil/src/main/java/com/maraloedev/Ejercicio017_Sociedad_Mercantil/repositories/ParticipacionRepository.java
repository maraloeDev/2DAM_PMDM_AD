package com.maraloedev.Ejercicio017_Sociedad_Mercantil.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maraloedev.Ejercicio017_Sociedad_Mercantil.entities.Participacion;

public interface ParticipacionRepository extends JpaRepository<Participacion, Long> {

}
