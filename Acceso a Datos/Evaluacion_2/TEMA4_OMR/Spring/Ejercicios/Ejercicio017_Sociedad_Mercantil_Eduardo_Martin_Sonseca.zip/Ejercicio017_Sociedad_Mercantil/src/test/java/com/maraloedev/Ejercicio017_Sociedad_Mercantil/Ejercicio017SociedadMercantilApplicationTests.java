package com.maraloedev.Ejercicio017_Sociedad_Mercantil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio017SociedadMercantilApplicationTests {

	@Test
	void contextLoads() {
	}

}
