package com.maraloedev.Ejercicio017_Sociedad_Mercantil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio017SociedadMercantilApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio017SociedadMercantilApplication.class, args);
	}

}
