package com.maraloedev.Ejercicio017_Sociedad_Mercantil.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.maraloedev.Ejercicio017_Sociedad_Mercantil.entities.Sociedad;

public interface SociedadRepository extends JpaRepository<Sociedad, Long> {

}
